const fs = require('fs')
const chalk = require('chalk')

//Edit Semua Sesuai Kebutuhan
global.owner = ['6285697886101']// no own
global.packname = '© PUTRA OFFC' // nama pack sticker
global.author = 'PUTRA OFFC'// nama author 
global.namaPanel = 'PANNEL PUTRA OFFC'
global.deskPanel = 'SUBSCRIBE YOUTUBE PUTRA OFFC'
global.groupPanel = 'https://bit.ly/3MQP46y'
global.nameKecil = 'putraoffc'
global.nameBot = 'BOT PANNEL'
global.nameOwner = 'PUTRA OFFC'
global.modeBot = 'PUBLIC'

//Konekin Server Mu Disini
global.domain = '-' // Isi Domain Lu
global.apikey = '-' // Isi Apikey Plta Lu
global.capikey = '-' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location

//Ganti Link nya menjadi link qris allpay mu
global.qris = 'https://telegra.ph/file/51a1553be863a0a73cf90.jpg'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.yellowBright(`Update File Terbaru ${__filename}`))
delete require.cache[file]
require(file)
})